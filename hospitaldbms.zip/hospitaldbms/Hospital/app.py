from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector
from mysql.connector import errorcode

app = Flask(__name__)
app.secret_key = 'your_secret_key'

def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='admin',
            password='YES',
            database='hospital_management'
        )
        return connection
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print("Something is wrong with your user name or password")
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print("Database does not exist")
        else:
            print(err)
        return None

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    user = None
    role = None
    for r in ['doctors', 'nurses', 'admins']:
        cursor.execute(f"SELECT * FROM {r} WHERE username=%s AND password=%s", (username, password))
        user = cursor.fetchone()
        if user:
            role = r[:-1]  # Assign the role based on the table name
            break

    cursor.close()
    connection.close()
    if user:
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['role'] = role
        if role == 'doctor':
            return redirect(url_for('doctor_dashboard'))
        elif role == 'nurse':
            return redirect(url_for('nurse_dashboard'))
        elif role == 'admin':
            return redirect(url_for('admin_dashboard'))
    return 'Invalid credentials'

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/doctor_dashboard')
def doctor_dashboard():
    if 'role' in session and session['role'] == 'doctor':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM patients WHERE assigned_doctor=%s", (session['username'],))
        patients = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template('doctor_dashboard.html', patients=patients)
    return redirect(url_for('home'))

@app.route('/nurse_dashboard')
def nurse_dashboard():
    if 'role' in session and session['role'] == 'nurse':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM patients")
        patients = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template('nurse_dashboard.html', patients=patients)
    return redirect(url_for('home'))

@app.route('/admin_dashboard')
def admin_dashboard():
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        cursor.execute("SELECT COUNT(*) AS count FROM patients")
        total_patients = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) AS count FROM doctors")
        total_doctors = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) AS count FROM nurses")
        total_nurses = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) AS count FROM admins")
        total_admins = cursor.fetchone()['count']
        
        cursor.execute("SELECT * FROM appointments")
        appointments = cursor.fetchall()

        cursor.execute("SELECT id, name, age, ward, bed_number, disease, assigned_doctor FROM patients")
        patients = cursor.fetchall()
        
        cursor.close()
        connection.close()
        
        user = {
            'id': session['user_id'],
            'username': session['username'],
            'role': session['role']
        }
        
        return render_template('admin_dashboard.html', 
                               total_patients=total_patients, 
                               total_doctors=total_doctors, 
                               total_nurses=total_nurses, 
                               total_admins=total_admins, 
                               appointments=appointments, 
                               patients=patients,
                               user=user)
    
    return redirect(url_for('home'))

@app.route('/book_appointment', methods=['GET', 'POST'])
def book_appointment():
    if 'role' in session and session['role'] == 'admin':
        if request.method == 'POST':
            patient_name = request.form['patient_name']
            doctor_id = request.form['doctor_id']
            appointment_date = request.form['appointment_date']
            appointment_time = request.form['appointment_time']
            
            connection = get_db_connection()
            cursor = connection.cursor()
            cursor.execute("INSERT INTO appointments (patient_name, doctor_id, appointment_date, appointment_time) VALUES (%s, %s, %s, %s)", 
                           (patient_name, doctor_id, appointment_date, appointment_time))
            connection.commit()
            cursor.close()
            connection.close()
            
            return redirect(url_for('admin_dashboard'))
        
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM patients")
        patients = cursor.fetchall()
        cursor.execute("SELECT * FROM doctors")
        doctors = cursor.fetchall()
        cursor.close()
        connection.close()
        
        return render_template('book_appointment.html', patients=patients, doctors=doctors)
    
    return redirect(url_for('home'))

@app.route('/add_patient', methods=['GET', 'POST'])
def add_patient():
    if 'role' in session and session['role'] in ['nurse', 'admin']:
        if request.method == 'POST':
            name = request.form['name']
            age = request.form['age']
            ward = request.form['ward']
            bed_number = request.form['bed_number']
            disease = request.form['disease']
            assigned_doctor = request.form['assigned_doctor']
            
            connection = get_db_connection()
            cursor = connection.cursor()
            cursor.execute("INSERT INTO patients (name, age, ward, bed_number, disease, assigned_doctor) VALUES (%s, %s, %s, %s, %s, %s)", 
                (name, age, ward, bed_number, disease, assigned_doctor))
            connection.commit()
            cursor.close()
            connection.close()
            
            return redirect(url_for('nurse_dashboard' if session['role'] == 'nurse' else 'admin_dashboard'))
        
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id, username FROM doctors")
        doctors = cursor.fetchall()
        cursor.close()
        connection.close()
        
        return render_template('add_patient.html', doctors=doctors)
    
    return redirect(url_for('home'))

@app.route('/add_staff', methods=['GET', 'POST'])
def add_staff():
    if 'role' in session and session['role'] == 'admin':
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            role = request.form['role']
            
            connection = get_db_connection()
            cursor = connection.cursor()
            if role == 'doctor':
                cursor.execute("INSERT INTO doctors (username, password) VALUES (%s, %s)", (username, password))
            elif role == 'nurse':
                cursor.execute("INSERT INTO nurses (username, password) VALUES (%s, %s)", (username, password))
            elif role == 'admin':
                cursor.execute("INSERT INTO admins (username, password) VALUES (%s, %s)", (username, password))
            connection.commit()
            cursor.close()
            connection.close()
            
            return redirect(url_for('admin_dashboard'))
        
        return render_template('add_staff.html')
    
    return redirect(url_for('home'))

@app.route('/delete_patient/<int:patient_id>', methods=['POST'])
def delete_patient(patient_id):
    if 'role' in session and session['role'] in ['nurse', 'admin']:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute("DELETE FROM patients WHERE id=%s", (patient_id,))
        connection.commit()
        cursor.close()
        connection.close()
        return redirect(url_for('nurse_dashboard' if session['role'] == 'nurse' else 'admin_dashboard'))
    
    return redirect(url_for('home'))

@app.route('/nurse/<int:nurse_id>')
def nurse_detail(nurse_id):
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM nurses WHERE id=%s", (nurse_id,))
        nurse = cursor.fetchone()
        cursor.close()
        connection.close()

        if nurse:
            return render_template('nurse_detail.html', nurse=nurse)
        return 'Nurse not found', 404

    return redirect(url_for('home'))

@app.route('/delete_user/<role>/<int:user_id>', methods=['POST'])
def delete_user(role, user_id):
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor()
        if role == 'doctor':
            cursor.execute("DELETE FROM doctors WHERE id=%s", (user_id,))
        elif role == 'nurse':
            cursor.execute("DELETE FROM nurses WHERE id=%s", (user_id,))
        connection.commit()
        cursor.close()
        connection.close()

        return redirect(url_for('doctors_list') if role == 'doctor' else url_for('nurses_list'))

    return redirect(url_for('home'))

@app.route('/doctors_list')
def doctors_list():
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM doctors")
        doctors = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template('doctors_list.html', doctors=doctors)
    return redirect(url_for('home'))

@app.route('/nurses_list')
def nurses_list():
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM nurses")
        nurses = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template('nurses_list.html', nurses=nurses)
    return redirect(url_for('home'))

@app.route('/patients_list')
def patients_list():
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM patients")
        patients = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template('patients_list.html', patients=patients)
    return redirect(url_for('home'))

@app.route('/patient/<int:patient_id>')
def patient_detail(patient_id):
    if 'role' in session and session['role'] in ['nurse', 'admin']:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM patients WHERE id=%s", (patient_id,))
        patient = cursor.fetchone()
        cursor.close()
        connection.close()

        if patient:
            return render_template('patient_detail.html', patient=patient)
        return 'Patient not found', 404

    return redirect(url_for('home'))

@app.route('/add_doctor', methods=['GET', 'POST'])
def add_doctor():
    if 'role' in session and session['role'] == 'admin':
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            degree = request.form['degree']
            experience = request.form['experience']
            specialization = request.form['specialization']
            
            connection = get_db_connection()
            cursor = connection.cursor()
            cursor.execute("INSERT INTO doctors (username, password, degree, experience, specialization) VALUES (%s, %s, %s, %s, %s)",
                           (username, password, degree, experience, specialization))
            connection.commit()
            cursor.close()
            connection.close()
            
            return redirect(url_for('admin_dashboard'))
        
        return render_template('add_doctor.html')
    
    return redirect(url_for('home'))

@app.route('/add_nurse', methods=['GET', 'POST'])
def add_nurse():
    if 'role' in session and session['role'] == 'admin':
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            
            connection = get_db_connection()
            cursor = connection.cursor()
            cursor.execute("INSERT INTO nurses (username, password) VALUES (%s, %s)", (username, password))
            connection.commit()
            cursor.close()
            connection.close()
            
            return redirect(url_for('admin_dashboard'))
        
        return render_template('add_nurse.html')
    
    return redirect(url_for('home'))

@app.route('/doctor/<int:doctor_id>')
def doctor_detail(doctor_id):
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM doctors WHERE id=%s", (doctor_id,))
        doctor = cursor.fetchone()
        cursor.close()
        connection.close()

        if doctor:
            return render_template('doctor_detail.html', doctor=doctor)
        return 'Doctor not found', 404

    return redirect(url_for('home'))

@app.route('/appointments_list')
def appointments_list():
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT id, patient_name, appointment_date, appointment_time from appointments
        """)
        appointments = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template('appointments_list.html', appointments=appointments)
    return redirect(url_for('home'))

@app.route('/appointment/<int:appointment_id>')
def appointment_detail(appointment_id):
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM appointments WHERE id=%s", (appointment_id,))
        appointment = cursor.fetchone()
        cursor.close()
        connection.close()

        if appointment:
            return render_template('appointment_detail.html', appointment=appointment)
        return 'Appointment not found', 404

    return redirect(url_for('home'))


@app.route('/delete_appointment/<int:appointment_id>', methods=['POST'])
def delete_appointment(appointment_id):
    if 'role' in session and session['role'] == 'admin':
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute("DELETE FROM appointments WHERE id=%s", (appointment_id,))
        connection.commit()
        cursor.close()
        connection.close()
        return redirect(url_for('appointments_list'))
    return redirect(url_for('home'))



if __name__ == '__main__':
    app.run(debug=True)
